'use strict';
const bcrypt = require('bcrypt');

module.exports = {
    up: async(queryInterface, Sequelize) => {
        const fields = [{
                name: 'Admin',
                email: 'admin@gmail.com',
                password: bcrypt.hashSync('1234', 10),
                role: 'admin',
                createdAt: new Date(),
                updatedAt: new Date()
            },
            {
                name: 'Magdalena',
                email: 'magdalena@gmail.com',
                password: bcrypt.hashSync('magdalena13', 10),
                role: 'content_creator',
                createdAt: new Date(),
                updatedAt: new Date()
            },
            {
                name: 'Sara',
                email: 'sara@gmail.com',
                password: bcrypt.hashSync('sara123', 10),
                role: 'content_creator',
                createdAt: new Date(),
                updatedAt: new Date()
            },
            {
                name: 'Lazar',
                email: 'lazar@gmail.com',
                password: bcrypt.hashSync('lazar123', 10),
                role: 'content_creator',
                createdAt: new Date(),
                updatedAt: new Date()
            },
            {
                name: 'Pavle',
                email: 'pavle@gmail.com',
                password: bcrypt.hashSync('pavle1234', 10),
                role: 'content_creator',
                createdAt: new Date(),
                updatedAt: new Date()
            }
        ]

        return queryInterface.bulkInsert('Users', fields, {});
    },

    down: async(queryInterface, Sequelize) => {
        return queryInterface.bulkDelete('Users', null, {});
    }
};