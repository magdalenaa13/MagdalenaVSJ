'use strict';
const {
    Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
    class Crew extends Model {

        static associate(models) {
            // define association here
        }
    };
    Crew.init({}, {
        sequelize,
        modelName: 'Crew',
    });
    return Crew;
};