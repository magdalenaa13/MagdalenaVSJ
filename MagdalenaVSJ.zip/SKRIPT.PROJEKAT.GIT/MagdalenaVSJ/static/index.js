function init(){
    console.log("started");
}
